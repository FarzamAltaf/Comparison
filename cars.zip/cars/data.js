var products = [
  {
    id: 0,
    title: "-- No Image --",
    price: "",
    description: "",
    brand: "",
    image: "images/No_Image.png",
  },

  {
    id: 1,
    title: "Mercedies Benz",
    price: 1700000,
    description:
      "Excellen car",
    brand: "Mercedies",
    image: "images/mercedies.png",
  },

  {
    id: 2,
    title: "Lamborghini Urus",
    price: 1599999999,
    description:
      "Marvellous Car",
    brand: "Lamborghini",
    image: "images/lamborghini-urus.jpg",
  },

  {
    id: 3,
    title: "bianco",
    price: 699999999,
    description:
      "Good Car",
    brand: "Ferrari",
    image: "images/bianco.webp",
  },
  {
    id: 4,
    title: "Audi etron",
    price: 369999999,
    description:
      "No Comments",
    brand: "Audi",
    image: "images/Audi-e-tron.webp",
  },
  {
    id: 5,
    title: "Audi E TRON GT RS",
    price: 35499,
    description:
      "SUPERB",
    brand: "Audi",
    image: "images/Audi-e-tron-gt-rs.png",
  },
];
